﻿
//===================problem1==========================
//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace LinqRestrictionOperators
//{
//    public class Product
//    {
//        public string ProductName { get; set; }
//        public int UnitsInStock { get; set; }
//        public decimal UnitPrice { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Product> products = new List<Product>
//            {
//                new Product { ProductName = "Apple", UnitsInStock = 0, UnitPrice = 1.5M },
//                new Product { ProductName = "Banana", UnitsInStock = 5, UnitPrice = 2.0M },
//                new Product { ProductName = "Orange", UnitsInStock = 10, UnitPrice = 3.5M },
//                new Product { ProductName = "Mango", UnitsInStock = 0, UnitPrice = 4.0M }
//            };

//            var outOfStock =
//                from p in products
//                where p.UnitsInStock == 0
//                select p;

//            Console.WriteLine("Products out of stock:");
//            foreach (var p in outOfStock)
//            {
//                Console.WriteLine(p.ProductName);
//            }

//            Console.WriteLine();

//            var expensiveInStock =
//                from p in products
//                where p.UnitsInStock > 0 && p.UnitPrice > 3.00M
//                select p;

//            Console.WriteLine("Products in stock and cost > 3.00:");
//            foreach (var p in expensiveInStock)
//            {
//                Console.WriteLine($"{p.ProductName} - {p.UnitPrice} USD");
//            }

//            Console.WriteLine();

//            string[] Arr =
//            { "zero", "one", "two", "three", "four",
//              "five", "six", "seven", "eight", "nine" };

//            var shortNames =
//                from item in Arr.Select((val, idx) => new { val, idx })
//                where item.val.Length < item.idx
//                select item.val;

//            Console.WriteLine("Digits with name shorter than value:");
//            foreach (var name in shortNames)
//            {
//                Console.WriteLine(name);
//            }
//        }
//    }
//}





//===================problem2==========================
//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace LinqElementOperators
//{
//    public class Product
//    {
//        public string ProductName { get; set; }
//        public int UnitsInStock { get; set; }
//        public decimal UnitPrice { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Product> products = new List<Product>
//            {
//                new Product { ProductName = "Apple", UnitsInStock = 0, UnitPrice = 1.5M },
//                new Product { ProductName = "Banana", UnitsInStock = 5, UnitPrice = 2.0M },
//                new Product { ProductName = "Orange", UnitsInStock = 10, UnitPrice = 1200M },
//                new Product { ProductName = "Mango", UnitsInStock = 0, UnitPrice = 4.0M }
//            };

//            var firstOutOfStock =
//                (from p in products
//                 where p.UnitsInStock == 0
//                 select p).First();

//            Console.WriteLine("First product out of stock:");
//            Console.WriteLine(firstOutOfStock.ProductName);

//            Console.WriteLine();

//            var firstExpensive =
//                (from p in products
//                 where p.UnitPrice > 1000
//                 select p).FirstOrDefault();

//            Console.WriteLine("First product with price > 1000:");
//            Console.WriteLine(firstExpensive != null ? firstExpensive.ProductName : "null");

//            Console.WriteLine();

//            int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

//            var secondGreaterThanFive =
//                (from n in Arr
//                 where n > 5
//                 select n).ElementAt(1);

//            Console.WriteLine("Second number greater than 5:");
//            Console.WriteLine(secondGreaterThanFive);
//        }
//    }
//}






//===================problem3==========================


//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace LinqAggregateOperators
//{
//    public class Product
//    {
//        public string ProductName { get; set; }
//        public int UnitsInStock { get; set; }
//        public decimal UnitPrice { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

//            int count = (from n in numbers select n).Count();
//            Console.WriteLine("Count of numbers: " + count);

//            List<Product> products = new List<Product>
//            {
//                new Product { ProductName = "Apple", UnitsInStock = 0, UnitPrice = 1.5M },
//                new Product { ProductName = "Banana", UnitsInStock = 5, UnitPrice = 2.0M },
//                new Product { ProductName = "Orange", UnitsInStock = 10, UnitPrice = 3.5M },
//                new Product { ProductName = "Mango", UnitsInStock = 0, UnitPrice = 4.0M }
//            };

//            int outOfStockCount =
//                (from p in products
//                 where p.UnitsInStock == 0
//                 select p).Count();
//            Console.WriteLine("Products out of stock: " + outOfStockCount);

//            var categoryCounts =
//                from p in products
//                group p by p.UnitsInStock > 0 into g
//                select new { Key = g.Key, Count = g.Count() };

//            Console.WriteLine("Category counts:");
//            foreach (var c in categoryCounts)
//            {
//                Console.WriteLine($"{(c.Key ? "InStock" : "OutOfStock")}: {c.Count}");
//            }

//            double totalChars =
//                (from w in new string[] { "apple", "banana", "mango", "orange" }
//                 select w.Length).Sum();
//            Console.WriteLine("Total characters: " + totalChars);

//            int longestLength =
//                (from w in new string[] { "apple", "banana", "mango", "orange" }
//                 select w.Length).Max();
//            Console.WriteLine("Longest word length: " + longestLength);

//            var mostExpensive =
//                (from p in products
//                 select p.UnitPrice).Max();
//            Console.WriteLine("Most expensive product price: " + mostExpensive);

//            var cheapestProduct =
//                (from p in products
//                 orderby p.UnitPrice
//                 select p).First();
//            Console.WriteLine("Cheapest product: " + cheapestProduct.ProductName);

//            int shortestWordLength =
//                (from w in new string[] { "apple", "banana", "mango", "orange" }
//                 select w.Length).Min();
//            Console.WriteLine("Shortest word length: " + shortestWordLength);

//            var leastExpensive =
//                (from p in products
//                 select p.UnitPrice).Min();
//            Console.WriteLine("Least expensive product price: " + leastExpensive);

//            var productWithLeastPrice =
//                (from p in products
//                 orderby p.UnitPrice
//                 select p).First();
//            Console.WriteLine("Product with least price: " + productWithLeastPrice.ProductName);

//            double averageNumber =
//                (from n in numbers select n).Average();
//            Console.WriteLine("Average of numbers: " + averageNumber);

//            var averagePrice =
//                (from p in products select p.UnitPrice).Average();
//            Console.WriteLine("Average product price: " + averagePrice);

//            double averageChars =
//                (from w in new string[] { "apple", "banana", "mango", "orange" }
//                 select w.Length).Average();
//            Console.WriteLine("Average word length: " + averageChars);
//        }
//    }
//}






//===================problem4==========================

//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace LinqOrderingOperators
//{
//    public class Product
//    {
//        public string ProductName { get; set; }
//        public int UnitsInStock { get; set; }
//        public decimal UnitPrice { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string[] words = { "cherry", "apple", "blueberry" };

//            var sortedWords =
//                from w in words
//                orderby w
//                select w;
//            Console.WriteLine("Sorted words:");
//            foreach (var w in sortedWords) Console.WriteLine(w);

//            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

//            var sortedNumbers =
//                from n in numbers
//                orderby n
//                select n;
//            Console.WriteLine("Sorted numbers:");
//            foreach (var n in sortedNumbers) Console.WriteLine(n);

//            var sortedWordsByLength =
//                from w in words
//                orderby w.Length
//                select w;
//            Console.WriteLine("Words sorted by length:");
//            foreach (var w in sortedWordsByLength) Console.WriteLine(w);

//            List<Product> products = new List<Product>
//            {
//                new Product { ProductName = "Apple", UnitsInStock = 0, UnitPrice = 1.5M },
//                new Product { ProductName = "Banana", UnitsInStock = 5, UnitPrice = 2.0M },
//                new Product { ProductName = "Orange", UnitsInStock = 10, UnitPrice = 3.5M },
//                new Product { ProductName = "Mango", UnitsInStock = 0, UnitPrice = 4.0M }
//            };

//            var sortedProducts =
//                from p in products
//                orderby p.ProductName
//                select p;
//            Console.WriteLine("Products sorted by name:");
//            foreach (var p in sortedProducts) Console.WriteLine(p.ProductName);

//            var numbersDesc =
//                from n in numbers
//                orderby n descending
//                select n;
//            Console.WriteLine("Numbers descending:");
//            foreach (var n in numbersDesc) Console.WriteLine(n);

//            var wordsDescByLength =
//                from w in words
//                orderby w.Length descending
//                select w;
//            Console.WriteLine("Words by length descending:");
//            foreach (var w in wordsDescByLength) Console.WriteLine(w);

//            var productsDescPrice =
//                from p in products
//                orderby p.UnitPrice descending
//                select p;
//            Console.WriteLine("Products by price descending:");
//            foreach (var p in productsDescPrice) Console.WriteLine($"{p.ProductName} - {p.UnitPrice}");

//            string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

//            var digitsSorted =
//                from d in digits
//                orderby d.Length, d
//                select d;
//            Console.WriteLine("Digits sorted by length then alphabetically:");
//            foreach (var d in digitsSorted) Console.WriteLine(d);

//            var productsSortedStockPrice =
//                from p in products
//                orderby p.UnitsInStock descending, p.UnitPrice descending
//                select p;
//            Console.WriteLine("Products by stock then price:");
//            foreach (var p in productsSortedStockPrice) Console.WriteLine($"{p.ProductName} - {p.UnitsInStock} - {p.UnitPrice}");
//        }
//    }
//}





//===================problem5==========================

//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace LinqTransformationOperators
//{
//    public class Product
//    {
//        public string ProductName { get; set; }
//        public decimal UnitPrice { get; set; }
//        public int UnitsInStock { get; set; }
//        public string Category { get; set; }
//    }

//    public class Order
//    {
//        public int OrderID { get; set; }
//        public decimal Total { get; set; }
//        public DateTime OrderDate { get; set; }
//    }

//    public class Customer
//    {
//        public string CustomerID { get; set; }
//        public List<Order> Orders { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Product> products = new List<Product>
//            {
//                new Product { ProductName = "Apple", UnitPrice = 1.5M, UnitsInStock = 0, Category = "Fruits" },
//                new Product { ProductName = "Banana", UnitPrice = 2.0M, UnitsInStock = 5, Category = "Fruits" },
//                new Product { ProductName = "Orange", UnitPrice = 3.5M, UnitsInStock = 10, Category = "Fruits" },
//                new Product { ProductName = "Laptop", UnitPrice = 1500M, UnitsInStock = 2, Category = "Electronics" }
//            };

//            List<Customer> customers = new List<Customer>
//            {
//                new Customer
//                {
//                    CustomerID = "C1",
//                    Orders = new List<Order>
//                    {
//                        new Order { OrderID = 1, Total = 450M, OrderDate = new DateTime(1997, 12, 1) },
//                        new Order { OrderID = 2, Total = 600M, OrderDate = new DateTime(1999, 1, 10) }
//                    }
//                },
//                new Customer
//                {
//                    CustomerID = "C2",
//                    Orders = new List<Order>
//                    {
//                        new Order { OrderID = 3, Total = 200M, OrderDate = new DateTime(2000, 5, 5) }
//                    }
//                }
//            };

//            var productNames =
//                from p in products
//                select p.ProductName;
//            Console.WriteLine("Product Names:");
//            foreach (var name in productNames) Console.WriteLine(name);

//            string[] words = { "aPPLE", "BlUeBeRrY", "cHeRry" };
//            var wordVariants =
//                from w in words
//                select new { Upper = w.ToUpper(), Lower = w.ToLower() };
//            Console.WriteLine("Word Variants:");
//            foreach (var w in wordVariants) Console.WriteLine($"{w.Upper} - {w.Lower}");

//            var projectedProducts =
//                from p in products
//                select new { p.ProductName, Price = p.UnitPrice, p.Category };
//            Console.WriteLine("Projected Products:");
//            foreach (var p in projectedProducts) Console.WriteLine($"{p.ProductName} - {p.Price} - {p.Category}");

//            int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//            var numberCheck =
//                from n in Arr
//                select new { Number = n, InPlace = (n == Array.IndexOf(Arr, n)) };
//            Console.WriteLine("Numbers In-Place:");
//            foreach (var item in numberCheck) Console.WriteLine($"{item.Number}: {item.InPlace}");

//            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
//            int[] numbersB = { 1, 3, 5, 7, 8 };
//            var pairs =
//                from a in numbersA
//                from b in numbersB
//                where a < b
//                select new { A = a, B = b };
//            Console.WriteLine("Pairs where a < b:");
//            foreach (var pair in pairs) Console.WriteLine($"{pair.A} is less than {pair.B}");

//            var smallOrders =
//                from c in customers
//                from o in c.Orders
//                where o.Total < 500M
//                select o;
//            Console.WriteLine("Orders < 500:");
//            foreach (var o in smallOrders) Console.WriteLine($"{o.OrderID} - {o.Total}");

//            var ordersFrom1998 =
//                from c in customers
//                from o in c.Orders
//                where o.OrderDate.Year >= 1998
//                select o;
//            Console.WriteLine("Orders from 1998 or later:");
//            foreach (var o in ordersFrom1998) Console.WriteLine($"{o.OrderID} - {o.OrderDate.Year}");
//        }
//    }
//}




//===================problem6==========================
//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace LinqPartitioningOperators
//{
//    public class Order
//    {
//        public int OrderID { get; set; }
//        public string CustomerID { get; set; }
//        public string Region { get; set; }
//        public DateTime OrderDate { get; set; }
//    }

//    public class Customer
//    {
//        public string CustomerID { get; set; }
//        public string Region { get; set; }
//        public List<Order> Orders { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Customer> customers = new List<Customer>
//            {
//                new Customer
//                {
//                    CustomerID = "C1",
//                    Region = "WA",
//                    Orders = new List<Order>
//                    {
//                        new Order { OrderID = 1, CustomerID = "C1", Region = "WA", OrderDate = DateTime.Now },
//                        new Order { OrderID = 2, CustomerID = "C1", Region = "WA", OrderDate = DateTime.Now },
//                        new Order { OrderID = 3, CustomerID = "C1", Region = "WA", OrderDate = DateTime.Now }
//                    }
//                },
//                new Customer
//                {
//                    CustomerID = "C2",
//                    Region = "NY",
//                    Orders = new List<Order>
//                    {
//                        new Order { OrderID = 4, CustomerID = "C2", Region = "NY", OrderDate = DateTime.Now }
//                    }
//                }
//            };

//            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

//            var first3OrdersWA =
//                (from c in customers
//                 where c.Region == "WA"
//                 from o in c.Orders
//                 select o).Take(3);
//            Console.WriteLine("First 3 orders from WA:");
//            foreach (var o in first3OrdersWA) Console.WriteLine(o.OrderID);

//            var skip2OrdersWA =
//                (from c in customers
//                 where c.Region == "WA"
//                 from o in c.Orders
//                 select o).Skip(2);
//            Console.WriteLine("All but first 2 orders from WA:");
//            foreach (var o in skip2OrdersWA) Console.WriteLine(o.OrderID);

//            var takeWhileNumbers =
//                numbers.TakeWhile((n, i) => n >= i);
//            Console.WriteLine("Numbers until one is less than its position:");
//            foreach (var n in takeWhileNumbers) Console.WriteLine(n);

//            var skipWhileNotDiv3 =
//                numbers.SkipWhile(n => n % 3 != 0);
//            Console.WriteLine("Numbers starting from first divisible by 3:");
//            foreach (var n in skipWhileNotDiv3) Console.WriteLine(n);

//            var skipWhileLessThanIndex =
//                numbers.SkipWhile((n, i) => n >= i);
//            Console.WriteLine("Numbers starting from first less than position:");
//            foreach (var n in skipWhileLessThanIndex) Console.WriteLine(n);
//        }
//    }
//}








//===================problem7==========================

//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;

//namespace LinqQuantifiersOperators
//{
//    public class Product
//    {
//        public string ProductName { get; set; }
//        public int UnitsInStock { get; set; }
//        public string Category { get; set; }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string[] dictionary = File.ReadAllLines("dictionary_english.txt");

//            var containsEI =
//                dictionary.Any(w => w.Contains("ei"));
//            Console.WriteLine($"Any word contains 'ei': {containsEI}");

//            List<Product> products = new List<Product>
//            {
//                new Product { ProductName = "Apple", UnitsInStock = 0, Category = "Fruits" },
//                new Product { ProductName = "Banana", UnitsInStock = 10, Category = "Fruits" },
//                new Product { ProductName = "Orange", UnitsInStock = 5, Category = "Fruits" },
//                new Product { ProductName = "Laptop", UnitsInStock = 0, Category = "Electronics" },
//                new Product { ProductName = "Mouse", UnitsInStock = 20, Category = "Electronics" }
//            };

//            var categoriesWithOutOfStock =
//                from p in products
//                group p by p.Category into g
//                where g.Any(p => p.UnitsInStock == 0)
//                select g;
//            Console.WriteLine("Categories with at least one product out of stock:");
//            foreach (var g in categoriesWithOutOfStock)
//            {
//                Console.WriteLine(g.Key);
//                foreach (var p in g) Console.WriteLine($"  {p.ProductName} - {p.UnitsInStock}");
//            }

//            var categoriesAllInStock =
//                from p in products
//                group p by p.Category into g
//                where g.All(p => p.UnitsInStock > 0)
//                select g;
//            Console.WriteLine("Categories with all products in stock:");
//            foreach (var g in categoriesAllInStock)
//            {
//                Console.WriteLine(g.Key);
//                foreach (var p in g) Console.WriteLine($"  {p.ProductName} - {p.UnitsInStock}");
//            }
//        }
//    }
//}








