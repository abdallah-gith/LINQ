﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace linq3
{
    

    public class AppDbContext : DbContext
    {
        public DbSet<Project> Projects { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
            optionsBuilder.UseSqlServer("Server=.;Database=MyDb;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Project>(b =>
            {
               
                b.HasKey(p => p.Id);
                b.Property(p => p.Id)
                       .UseIdentityColumn( 10,  10);
                
                b.Property(p => p.Name)
                       .IsRequired()
                       .HasColumnType("varchar(50)")
                       .HasDefaultValue("Project");

                b.Property(p => p.Cost)
                       .HasColumnType("money");

                b.HasCheckConstraint("CK_Project_Cost", "Cost BETWEEN 500000 AND 3500000");
            });
        }
    }

}
