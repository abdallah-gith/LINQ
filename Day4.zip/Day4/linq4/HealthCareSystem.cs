﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

// =================================================================
// 1. ENTITY CLASSES (النماذج التي تمثل جداول قاعدة البيانات)
// =================================================================

public class Patient
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime DateOfBirth { get; set; }
    public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
}

public class Doctor
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Specialization { get; set; }
    public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
}

// Junction entity for the many-to-many relationship
public class Appointment
{
    public int PatientId { get; set; }
    public Patient Patient { get; set; }
    public int DoctorId { get; set; }
    public Doctor Doctor { get; set; }
    public DateTime AppointmentDate { get; set; }
}

// =================================================================
// 2. DBCONTEXT CLASS (الكلاس الذي يربط الكود بقاعدة البيانات)
// =================================================================

public class HealthCareDbContext : DbContext
{
    // سلسلة الاتصال مكتوبة مباشرة هنا مع استخدام اسم السيرفر الخاص بك
    private const string ConnectionString = "Server=ABDALLAH;Database=HealthCareDB_Simple;Trusted_Connection=True;TrustServerCertificate=True;";

    public DbSet<Patient> Patients { get; set; }
    public DbSet<Doctor> Doctors { get; set; }
    public DbSet<Appointment> Appointments { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(ConnectionString);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // A unique appointment is identified by the patient, the doctor, and the exact date and time.
        modelBuilder.Entity<Appointment>()
            .HasKey(a => new { a.PatientId, a.DoctorId, a.AppointmentDate });
    }
}