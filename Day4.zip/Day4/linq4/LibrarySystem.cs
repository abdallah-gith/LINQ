﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

public class Author
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime BirthDate { get; set; }
    public ICollection<Book> Books { get; set; } = new List<Book>();
}

public class Book
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string ISBN { get; set; }
    public int AuthorId { get; set; }
    public Author Author { get; set; }
    public ICollection<Loan> Loans { get; set; } = new List<Loan>();
}

public class Borrower
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime MembershipDate { get; set; }
    public ICollection<Loan> Loans { get; set; } = new List<Loan>();
}

public class Loan
{
    public int BookId { get; set; }
    public Book Book { get; set; }
    public int BorrowerId { get; set; }
    public Borrower Borrower { get; set; }
    public DateTime LoanDate { get; set; }
    public DateTime? ReturnDate { get; set; } 
}


public class LibraryDbContext : DbContext
{
 
    private const string ConnectionString = "Server=ABDALLAH;Database=LibraryDB_Simple;Trusted_Connection=True;TrustServerCertificate=True;";

    public DbSet<Book> Books { get; set; }
    public DbSet<Author> Authors { get; set; }
    public DbSet<Borrower> Borrowers { get; set; }
    public DbSet<Loan> Loans { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(ConnectionString);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      
        modelBuilder.Entity<Loan>()
            .HasKey(l => new { l.BookId, l.BorrowerId, l.LoanDate });
    }
}