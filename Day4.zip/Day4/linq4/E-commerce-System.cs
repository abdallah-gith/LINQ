﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

// =================================================================
// 1. ENTITY CLASSES (النماذج التي تمثل جداول قاعدة البيانات)
// =================================================================

public class Category
{
    public int Id { get; set; }
    public string Name { get; set; }
    public ICollection<Product> Products { get; set; } = new List<Product>();
}

public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    public int CategoryId { get; set; }
    public Category Category { get; set; }
    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}

public class Customer
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public ICollection<Order> Orders { get; set; } = new List<Order>();
}

public class Order
{
    public int Id { get; set; }
    public DateTime OrderDate { get; set; }
    public int CustomerId { get; set; }
    public Customer Customer { get; set; }
    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}

public class OrderDetail
{
    public int OrderId { get; set; }
    public Order Order { get; set; }
    public int ProductId { get; set; }
    public Product Product { get; set; }
    public int Quantity { get; set; }
}


// =================================================================
// 2. DBCONTEXT CLASS (الكلاس الذي يربط الكود بقاعدة البيانات)
// =================================================================

public class EcommerceDbContext : DbContext
{
    // سلسلة الاتصال مكتوبة مباشرة هنا
    private const string ConnectionString = "Server=ABDALLAH;Database=EcommerceDB_Simple;Trusted_Connection=True;TrustServerCertificate=True;";
    public DbSet<Product> Products { get; set; }
    public DbSet<Category> Categories { get; set; }
    public DbSet<Customer> Customers { get; set; }
    public DbSet<Order> Orders { get; set; }
    public DbSet<OrderDetail> OrderDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // هنا نخبر Entity Framework باستخدام سلسلة الاتصال هذه
        optionsBuilder.UseSqlServer(ConnectionString);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // This configures the composite primary key for the junction table
        modelBuilder.Entity<OrderDetail>()
            .HasKey(od => new { od.OrderId, od.ProductId });
    }
}